import { useState } from "react";
import { useParams } from "react-router-dom";
import tours from "../data/Tours.js";
import "../styles/TourDetail.css";

function TourDetailPage() {
  const { id } = useParams();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    date: '',
    count: '1',
    days: '1',
    cardNumber: '',
    expiry: '',
    cvc: ''
  });

  const tour = tours.find(t => t.id.toString() === id);
  const totalPrice = tour ? tour.price * Number(formData.count) : 0;

  // რეგიონების რუკების URL-ები
  const getMapUrl = (region) => {
    const mapUrls = {
      'აჭარა': 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d190778.0!2d41.57!3d41.64!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x406786c41eb98bed%3A0x7f0b6d9c426c0b0d!2sBatumi%2C%20Georgia!5e0!3m2!1sen!2sge!4v1616589627496!5m2!1sen!2sge',
      'თუშეთი': 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d95389.0!2d45.60!3d42.45!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4044c8e4c5e5f5f5%3A0x5f5f5f5f5f5f5f5f!2sTusheti%2C%20Georgia!5e0!3m2!1sen!2sge!4v1616589627496!5m2!1sen!2sge',
      'ბორჯომი': 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d95389.0!2d43.39!3d41.84!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4044c7c4c4c4c4c4%3A0x4c4c4c4c4c4c4c4c!2sBorjomi%2C%20Georgia!5e0!3m2!1sen!2sge!4v1616589627496!5m2!1sen!2sge',
      'კახეთი': 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d190778.0!2d45.70!3d41.90!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4044c8e8e8e8e8e8%3A0x8e8e8e8e8e8e8e8e!2sKakheti%2C%20Georgia!5e0!3m2!1sen!2sge!4v1616589627496!5m2!1sen!2sge',
      'სვანეთი': 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d95389.0!2d42.80!3d43.05!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4044c9c9c9c9c9c9%3A0x9c9c9c9c9c9c9c9c!2sSvaneti%2C%20Georgia!5e0!3m2!1sen!2sge!4v1616589627496!5m2!1sen!2sge',
      'ქუთაისი': 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d95389.0!2d42.70!3d42.27!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4044cacacacacaca%3A0xacacacacacacacac!2sKutaisi%2C%20Georgia!5e0!3m2!1sen!2sge!4v1616589627496!5m2!1sen!2sge',
      'სტეფანწმინდა': 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d95389.0!2d44.65!3d42.66!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4044cbcbcbcbcbcb%3A0xbcbcbcbcbcbcbcbc!2sStepantsminda%2C%20Georgia!5e0!3m2!1sen!2sge!4v1616589627496!5m2!1sen!2sge',
      'იმერეთი': 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d190778.0!2d42.60!3d42.10!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4044cccccccccccc%3A0xcccccccccccccccc!2sImereti%2C%20Georgia!5e0!3m2!1sen!2sge!4v1616589627496!5m2!1sen!2sge',
      'თბილისი': 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d95389.68263228217!2d44.706489!3d41.715137!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40440cd305d290b5%3A0x94963c73d90ff3a!2sTbilisi!5e0!3m2!1sen!2sge!4v1616589627496!5m2!1sen!2sge',
      'სამეგრელო': 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d190778.0!2d42.20!3d42.50!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4044cdcdcdcdcdcd%3A0xdcdcdcdcdcdcdcdc!2sSamegrelo%2C%20Georgia!5e0!3m2!1sen!2sge!4v1616589627496!5m2!1sen!2sge',
      'გურია': 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d95389.0!2d41.95!3d41.95!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4044ceceececece%3A0xecececececececec!2sGuria%2C%20Georgia!5e0!3m2!1sen!2sge!4v1616589627496!5m2!1sen!2sge',
      'რაჭა': 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d95389.0!2d43.10!3d42.50!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4044cfcfcfcfcfcf%3A0xfcfcfcfcfcfcfcfc!2sRacha%2C%20Georgia!5e0!3m2!1sen!2sge!4v1616589627496!5m2!1sen!2sge',
      'ხევსურეთი': 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d95389.0!2d45.15!3d42.50!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4044d0d0d0d0d0d0%3A0xd0d0d0d0d0d0d0d0!2sKhevsureti%2C%20Georgia!5e0!3m2!1sen!2sge!4v1616589627496!5m2!1sen!2sge',
      'მცხეთა-მთიანეთი': 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d95389.0!2d44.72!3d41.84!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4044d1d1d1d1d1d1%3A0xd1d1d1d1d1d1d1d1!2sMtskheta%2C%20Georgia!5e0!3m2!1sen!2sge!4v1616589627496!5m2!1sen!2sge',
      'შიდა ქართლი': 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d190778.0!2d44.10!3d41.85!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4044d2d2d2d2d2d2%3A0xd2d2d2d2d2d2d2d2!2sShida%20Kartli%2C%20Georgia!5e0!3m2!1sen!2sge!4v1616589627496!5m2!1sen!2sge',
      'სამცხე-ჯავახეთი': 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d190778.0!2d43.25!3d41.50!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4044d3d3d3d3d3d3%3A0xd3d3d3d3d3d3d3d3!2sSamtskhe-Javakheti%2C%20Georgia!5e0!3m2!1sen!2sge!4v1616589627496!5m2!1sen!2sge',
      'საქართველო': 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1528778.0!2d43.50!3d42.00!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40440cd7e64f626b%3A0x61d084ede2576ea3!2sGeorgia!5e0!3m2!1sen!2sge!4v1616589627496!5m2!1sen!2sge'
    };
    
    return mapUrls[region] || mapUrls['თბილისი']; // დეფოლტ თბილისის რუკა
  };

  if (!tour) {
    return <div className="tour-detail">ტური ვერ მოიძებნა</div>;
  }

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleBooking = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setShowPayment(false);
    setFormData({
      name: '',
      phone: '',
      date: '',
      count: '1',
      days: '1',
      cardNumber: '',
      expiry: '',
      cvc: ''
    });
  };

  const handleNextStep = () => {
    const { name, phone, date, count } = formData;
    if (!name.trim() || !phone.trim() || !date || !count) {
      alert("გთხოვთ შეავსოთ ყველა ველი.");
      return;
    }
    setShowPayment(true);
  };

  const handlePayment = (e) => {
    e.preventDefault();
    const { cardNumber, expiry, cvc, name, phone, date, count, days } = formData;
    if (!cardNumber || !expiry || !cvc) {
      alert("გთხოვთ შეავსოთ გადახდის ყველა ველი.");
      return;
    }

    alert(`✅ გადახდა შესრულდა:
👤 ${name}
📞 ${phone}
📅 თარიღი: ${date}
👥 ადამიანი: ${count}
🗓️ დღეები: ${days}
💳 ბარათი: ${cardNumber}
💰 ჯამური ფასი: ${totalPrice} ₾`);
    closeModal();
  };

  return (
    <div className="tour-detail fade-in">
      <img src={`/images/${tour.image}`} alt={tour.title} className="tour-detail-img" />
      <h2 className="tour-detail-title">{tour.title}</h2>

      <p className="tour-detail-info">📍 რეგიონი: {tour.region}</p>
      <p className="tour-detail-info">💵 ფასი ერთ ადამიანზე: {tour.price} ₾</p>
      <p className="tour-detail-info">👁️ ნახვები: {tour.views}</p>
      <p className="tour-detail-info">💰 ჯამური ფასი: {totalPrice} ₾</p>

      <p className="tour-detail-description">
        {tour.info || "ეს ტური წარმოგიდგენთ საუკეთესო გამოცდილებას თქვენს რეგიონში!"}
      </p>

      {/* დღის გეგმა */}
      <div className="tour-section">
        <h3>📆 დღის გეგმა:</h3>
        <ul className="day-plan">
          <li>09:00 - გასვლა თბილისიდან</li>
          <li>11:00 - გაჩერება ხიდზე / ფოტო</li>
          <li>13:00 - ლანჩი ტრადიციულ რესტორანში</li>
          <li>15:00 - ძირითადი ლოკაციების დათვალიერება</li>
          <li>19:00 - დაბრუნება</li>
        </ul>
      </div>

      {/* რჩევები ტურისტისთვის */}
      <div className="tour-section tips">
        <h3>💡 რჩევები ტურისტებისთვის:</h3>
        <ul>
          <li>✅ ჩაიცვით კომფორტულად და სპორტულად</li>
          <li>☀️ თან იქონიეთ სათვალე, ქუდი და მზისგან დამცავი</li>
          <li>💧 ნუ დაგავიწყდებათ წყალი</li>
          <li>📸 ფოტოაპარატი ან მობილური სრულად დატენილი</li>
        </ul>
      </div>

      {/* რუკა - ახლა დინამიურია რეგიონის მიხედვით */}
      <div className="tour-section map">
        <h3>🌍 {tour.region}ის მარშრუტი რუკაზე:</h3>
        <iframe
          title={`${tour.region} Map`}
          src={getMapUrl(tour.region)}
          width="100%"
          height="300"
          style={{ border: 0 }}
          allowFullScreen=""
          loading="lazy"
        ></iframe>
      </div>

      <button className="book-btn" onClick={handleBooking}>
        დაჯავშნა
      </button>

      {/* მოდალი */}
      {isModalOpen && (
        <div className="modal-overlay">
          <div className="modal">
            <span className="close-btn" onClick={closeModal}>×</span>

            {!showPayment ? (
              <form className="booking-form">
                <h3>დაჯავშნის ფორმა</h3>
                {/* ველები */}
                <label>სახელი:<input type="text" name="name" value={formData.name} onChange={handleInputChange} required /></label>
                <label>ტელეფონი:<input type="tel" name="phone" value={formData.phone} onChange={handleInputChange} required /></label>
                <label>თარიღი:<input type="date" name="date" value={formData.date} onChange={handleInputChange} required /></label>
                <label>რაოდენობა:<input type="number" name="count" value={formData.count} onChange={handleInputChange} min="1" required /></label>
                <label>ხანგრძლივობა:
                  <select name="days" value={formData.days} onChange={handleInputChange}>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="5">5</option>
                    <option value="7">7</option>
                  </select> დღე
                </label>
                <p className="tour-detail-info">💰 ჯამური ფასი: {totalPrice} ₾</p>
                <button type="button" onClick={handleNextStep}>გაგრძელება</button>
              </form>
            ) : (
              <form className="payment-fields" onSubmit={handlePayment}>
                <h4>გადახდის ინფორმაცია</h4>
                <label>💳 ბარათის ნომერი:<input type="text" name="cardNumber" placeholder="1234 5678 9012 3456" maxLength="19" value={formData.cardNumber} onChange={handleInputChange} required /></label>
                <label>📅 ვადა:<input type="text" name="expiry" placeholder="08/25" maxLength="5" value={formData.expiry} onChange={handleInputChange} required /></label>
                <label>🔒 CVC:<input type="text" name="cvc" placeholder="123" maxLength="3" value={formData.cvc} onChange={handleInputChange} required /></label>
                <p className="tour-detail-info">💰 გადასახდელი: {totalPrice} ₾</p>
                <button type="submit">გადახდა და დაჯავშნა</button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default TourDetailPage;