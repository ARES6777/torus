import React from "react";
import "../styles/contact.css";

function Contact() {
  return React.createElement(
    "div",
    { className: "contact-page" },

    // Hero
    React.createElement(
      "div",
      { className: "contact-hero fade-in" },
      React.createElement("h1", null, "დაგვიკავშირდით"),
      React.createElement("p", null, "იმოგზაურეთ საქართველოს მაშტაბით 🌊")
    ),

    React.createElement(
      "div",
      { className: "contact-container fade-in-up" },

      React.createElement(
        "form",
        { className: "contact-form" },
        React.createElement("h2", null, "დაგვიწერეთ"),

        React.createElement("input", {
          type: "text",
          placeholder: "სახელი და გვარი",
          required: true
        }),

        React.createElement("input", {
          type: "email",
          placeholder: "ელ-ფოსტა",
          required: true
        }),

        React.createElement("input", {
          type: "tel",
          placeholder: "ტელეფონი"
        }),

        React.createElement("textarea", {
          placeholder: "თქვენი შეტყობინება",
          rows: 5,
          required: true
        }),

        React.createElement(
          "button",
          { type: "submit" },
          "გაგზავნა"
        )
      ),

      React.createElement(
        "div",
        { className: "contact-info" },
        React.createElement("h2", null, "საკონტაქტო ინფორმაცია"),
        React.createElement("p", null, "📍 ბათუმი, საქართველო"),
        React.createElement("p", null, "📞 +995 555 123 456"),
        React.createElement("p", null, "✉️ TouristCo@gmail.com"),
        React.createElement("p", null, "🕒 მუშაობის დრო: 09:00 - 18:00"),

        React.createElement("iframe", {
          src: "https://maps.google.com/maps?q=Batumi&t=&z=13&ie=UTF8&iwloc=&output=embed",
          width: "100%",
          height: "200",
          style: { border: 0, marginTop: "20px", borderRadius: "10px" },
          allowFullScreen: true,
          loading: "lazy"
        })
      )
    )
  );
}

export default Contact;
