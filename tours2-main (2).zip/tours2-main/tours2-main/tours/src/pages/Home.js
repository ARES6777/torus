import { Link, useLocation } from "react-router-dom";

export default function Home() {
  const location = useLocation();
  
  const getActiveTab = () => {
    const path = location.pathname.toLowerCase();
    if (path.includes('hotels')) return 'hotels';
    if (path.includes('cars')) return 'cars';
    if (path.includes('restaurants')) return 'restaurants';
    if (path.includes('tours')) return 'tours';
    return 'search-all';
  };

  const activeTab = getActiveTab();

  return (
    <div>
      <div className="search-menu">
        <div className={`menu-item ${activeTab === 'search-all' ? 'active' : ''}`}>
          <Link to="/" className="menu-link">
            Search All
            <div className="underline" />
          </Link>
        </div>
        <div className={`menu-item ${activeTab === 'hotels' ? 'active' : ''}`}>
          <Link to="/hotels" className="menu-link">
            Hotels
            <div className="underline" />
          </Link>
        </div>
        <div className={`menu-item ${activeTab === 'cars' ? 'active' : ''}`}>
          <Link to="/cars" className="menu-link">
            Cars for Rent
            <div className="underline" />
          </Link>
        </div>
        <div className={`menu-item ${activeTab === 'restaurants' ? 'active' : ''}`}>
          <Link to="/restaurants" className="menu-link">
            Restaurants
            <div className="underline" />
          </Link>
        </div>
        <div className={`menu-item ${activeTab === 'tours' ? 'active' : ''}`}>
          <Link to="/tours" className="menu-link">
            tours
            <div className="underline" />
          </Link>
        </div>
      </div>
      
      <div className="content">
        <h1>Welcome to Travel Explorer</h1>
        <p className="subtitle">Find the best travel deals for your next adventure in Georgia</p>
        
        {/* Hotels Section First */}
        <div className="featured-section">
          <h2>Experience Georgian Hospitality</h2>
          <p>Discover the best places to stay during your Georgian adventure</p>
          
          <div className="cuisine-highlights">
            <div className="cuisine-card">
              <div className="cuisine-image luxury-hotel"></div>
              <h3>Luxury Stays</h3>
              <p>5-star hotels with mountain views and premium amenities</p>
            </div>
            <div className="cuisine-card">
              <div className="cuisine-image guesthouse"></div>
              <h3>Traditional Guesthouses</h3>
              <p>Authentic Georgian homes with local hospitality</p>
            </div>
            <div className="cuisine-card">
              <div className="cuisine-image wine-resort"></div>
              <h3>Wine Resorts</h3>
              <p>Vineyard estates with wine tasting experiences</p>
            </div>
          </div>
          
          <Link to="/hotels" className="explore-btn">
            Explore Georgian Hotels
          </Link>
        </div>
        
        {/* Restaurants Section Second */}
        <div className="featured-section">
          <h2>Experience Georgian Cuisine</h2>
          <p>Discover the rich flavors of Georgia's world-renowned culinary traditions</p>
          
          <div className="cuisine-highlights">
            <div className="cuisine-card">
              <div className="cuisine-image khinkali"></div>
              <h3>Khinkali</h3>
              <p>Juicy dumplings filled with spiced meat and herbs</p>
            </div>
            <div className="cuisine-card">
              <div className="cuisine-image khachapuri"></div>
              <h3>Khachapuri</h3>
              <p>Cheese-filled bread in various regional styles</p>
            </div>
            <div className="cuisine-card">
              <div className="cuisine-image churchkhela"></div>
              <h3>Churchkhela</h3>
              <p>Traditional candle-shaped candy made from grape must</p>
            </div>
          </div>
          
          <Link to="/restaurants" className="explore-btn">
            Explore Georgian Restaurants
          </Link>
        </div>
        
        {/* Cars Section Third */}
        <div className="featured-section">
          <h2>Explore Georgia on Wheels</h2>
          <p>Find the perfect vehicle for your Georgian road trip adventure</p>
          
          <div className="cuisine-highlights">
            <div className="cuisine-card">
              <div className="cuisine-image suv"></div>
              <h3>SUVs & 4x4s</h3>
              <p>Comfortable vehicles for mountain roads and off-road adventures</p>
            </div>
            <div className="cuisine-card">
              <div className="cuisine-image sedan"></div>
              <h3>Economy Sedans</h3>
              <p>Fuel-efficient options for city driving and highway travel</p>
            </div>
            <div className="cuisine-card">
              <div className="cuisine-image luxury"></div>
              <h3>Luxury Vehicles</h3>
              <p>Premium cars for special occasions and comfortable journeys</p>
            </div>
          </div>
          
          <Link to="/cars" className="explore-btn">
            Explore Car Rental Options
          </Link>
        </div>
      </div>
    </div>
  );
}