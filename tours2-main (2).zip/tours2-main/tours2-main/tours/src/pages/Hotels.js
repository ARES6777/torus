import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import "./Hotels.css";

export default function Hotels() {
  const location = useLocation();
  const [activeFilter, setActiveFilter] = useState("All");
  const [selectedHotel, setSelectedHotel] = useState(null);
  const [bookingDates, setBookingDates] = useState({
    checkInDate: "",
    checkOutDate: "",
    guests: 1
  });

  const getActiveTab = () => {
    const path = location.pathname.toLowerCase();
    if (path.includes('hotels')) return 'hotels';
    if (path.includes('cars')) return 'cars';
    if (path.includes('restaurants')) return 'restaurants';
    if (path.includes('tours')) return 'tours';
    return 'search-all';
  };

  const activeTab = getActiveTab();

  // Georgian hotels data with tags
  const georgianHotels = [
    {
      id: 1,
      name: "Rooms Hotel Tbilisi",
      location: "Tbilisi",
      description: "Design hotel in the heart of the city with stunning views",
      rating: 4.9,
      price: 150,
      image: "rooms-tbilisi",
      features: ["Free WiFi", "Swimming Pool", "Spa", "Restaurant"],
      tags: ["Tbilisi", "Luxury"],
      details: "Rooms Hotel Tbilisi offers a unique blend of contemporary design and Georgian heritage. Located in the historic Vera district, it features spacious rooms with floor-to-ceiling windows, a rooftop pool with panoramic city views, and a renowned restaurant serving modern Georgian cuisine. The hotel's library bar is a popular spot for creative professionals and travelers alike."
    },
    {
      id: 2,
      name: "Stamba Hotel",
      location: "Tbilisi",
      description: "Industrial-chic hotel with botanical atrium and casino",
      rating: 4.8,
      price: 220,
      image: "stamba",
      features: ["Casino", "Rooftop Bar", "Library", "Free Parking"],
      tags: ["Tbilisi", "Luxury"],
      details: "Housed in a former Soviet-era printing plant, Stamba Hotel is a masterpiece of industrial design. Its centerpiece is a stunning five-story botanical atrium. The hotel features a casino, cinema, photo studio, and several acclaimed dining venues. Rooms showcase concrete finishes with warm wood accents and custom-made furniture."
    },
    {
      id: 3,
      name: "Rooms Hotel Kazbegi",
      location: "Stepantsminda",
      description: "Mountain retreat with panoramic views of Mount Kazbek",
      rating: 4.9,
      price: 180,
      image: "rooms-kazbegi",
      features: ["Mountain View", "Fireplace", "Hiking", "Spa"],
      tags: ["Mountains", "Luxury", "Resorts"],
      details: "Nestled in the Caucasus Mountains with breathtaking views of Mount Kazbek, Rooms Hotel Kazbegi is a sanctuary for nature lovers. The design incorporates local materials like wood and stone, with cozy common areas featuring fireplaces. Guests can enjoy guided hikes, relax in the spa with mountain views, or savor traditional Georgian dishes in the panoramic restaurant."
    },
    {
      id: 4,
      name: "Radisson Blu Batumi",
      location: "Batumi",
      description: "Beachfront hotel with Black Sea views and casino",
      rating: 4.7,
      price: 120,
      image: "radisson-batumi",
      features: ["Beach Access", "Casino", "Pool", "Spa"],
      tags: ["Batumi", "Resorts"],
      details: "Located on Batumi Boulevard overlooking the Black Sea, Radisson Blu offers modern luxury with direct beach access. The hotel features an indoor and outdoor pool, full-service spa, and several dining options including a seafood restaurant. Rooms feature contemporary design with sea or city views, and the casino offers entertainment into the night."
    },
    {
      id: 5,
      name: "Tsinandali Estate",
      location: "Telavi",
      description: "Luxury resort in Georgia's premier wine region",
      rating: 4.8,
      price: 250,
      image: "tsinandali",
      features: ["Wine Tasting", "Golf Course", "Pool", "Fine Dining"],
      tags: ["Resorts", "Luxury"],
      details: "Set in the heart of Georgia's wine country, Tsinandali Estate combines luxury with cultural heritage. The resort features an 18-hole golf course designed by Gary Player, a world-class spa, and a historic winery offering tastings. Accommodations range from elegant rooms in the historic mansion to private villas surrounded by vineyards."
    },
    {
      id: 6,
      name: "Sheraton Grand Tbilisi",
      location: "Tbilisi",
      description: "Modern luxury in the historic district near Old Town",
      rating: 4.7,
      price: 160,
      image: "sheraton",
      features: ["City View", "Spa", "Fitness Center", "Restaurant"],
      tags: ["Tbilisi", "Luxury"],
      details: "Situated near Tbilisi's historic Old Town, Sheraton Grand offers contemporary luxury with stunning views of the city and Narikala Fortress. The hotel features a full-service spa, indoor pool, and multiple dining options including a rooftop restaurant. Rooms feature the Sheraton Signature Sleep Experience and marble bathrooms."
    },
    {
      id: 7,
      name: "Wyndham Batumi",
      location: "Batumi",
      description: "Tower hotel with panoramic sea and city views",
      rating: 4.6,
      price: 110,
      image: "wyndham",
      features: ["Infinity Pool", "Casino", "Spa", "Sea View"],
      tags: ["Batumi", "Resorts"],
      details: "Standing as one of Batumi's tallest buildings, Wyndham offers unparalleled views of the Black Sea and city skyline. The hotel features an infinity pool on the top floor, a full-service casino, and a spa with traditional Georgian treatments. Modern rooms feature floor-to-ceiling windows, and multiple restaurants offer international cuisine."
    },
    {
      id: 8,
      name: "Lopota Lake Resort",
      location: "Kakheti",
      description: "Lakefront resort surrounded by Caucasus mountains",
      rating: 4.8,
      price: 140,
      image: "lopota",
      features: ["Private Beach", "Water Sports", "Spa", "Wine Cellar"],
      tags: ["Resorts", "Mountains"],
      details: "Set on a picturesque lake in Georgia's Kakheti wine region, Lopota Lake Resort offers a peaceful retreat surrounded by mountains. The resort features a private beach, water sports facilities, tennis courts, and a spa. Accommodations include rooms in the main building and private cottages. The wine cellar offers tastings of local vintages."
    }
  ];

  // Filter hotels based on active filter
  const filteredHotels = georgianHotels.filter(hotel => {
    if (activeFilter === "All") return true;
    
    // Special cases
    if (activeFilter === "Mountains") {
      return hotel.tags.includes("Mountains");
    }
    
    if (activeFilter === "Luxury") {
      return hotel.tags.includes("Luxury");
    }
    
    if (activeFilter === "Resorts") {
      return hotel.tags.includes("Resorts");
    }
    
    return hotel.location === activeFilter;
  });

  const handleBookNow = (hotel) => {
    setSelectedHotel(hotel);
    window.scrollTo(0, 0);
  };

  const handleBackToList = () => {
    setSelectedHotel(null);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setBookingDates(prev => ({ ...prev, [name]: value }));
  };

  const handleBookingSubmit = (e) => {
    e.preventDefault();
    alert(`Booking confirmed at ${selectedHotel.name}\nCheck-in: ${bookingDates.checkInDate}\nCheck-out: ${bookingDates.checkOutDate}\nGuests: ${bookingDates.guests}`);
    // In real app: API call to process booking
  };

  if (selectedHotel) {
    return (
      <div className="hotel-detail-container">
        <button onClick={handleBackToList} className="back-button">
          &larr; Back to Hotels
        </button>
        
        <div className="hotel-detail-header">
          <h1>{selectedHotel.name}</h1>
          <p className="subtitle">{selectedHotel.location} | ${selectedHotel.price}/night</p>
        </div>
        
        <div className="hotel-detail-content">
          <div className="hotel-image-container">
            <div className={`hotel-detail-image ${selectedHotel.image}`}>
              <div className="rating">
                <span className="star">★</span> {selectedHotel.rating}
              </div>
              <div className="price-tag">
                ${selectedHotel.price}<span>/night</span>
              </div>
            </div>
          </div>
          
          <div className="hotel-info">
            <h2>Hotel Overview</h2>
            <p>{selectedHotel.details}</p>
            
            <div className="features-section">
              <h3>Hotel Features</h3>
              <div className="features-grid">
                {selectedHotel.features.map((feature, index) => (
                  <div key={index} className="feature-item">
                    <span className="feature-icon">✓</span> {feature}
                  </div>
                ))}
              </div>
            </div>
            
            <div className="booking-form">
              <h2>Book Your Stay</h2>
              <form onSubmit={handleBookingSubmit}>
                <div className="form-row">
                  <div className="form-group">
                    <label>Check-in Date</label>
                    <input
                      type="date"
                      name="checkInDate"
                      value={bookingDates.checkInDate}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  
                  <div className="form-group">
                    <label>Check-out Date</label>
                    <input
                      type="date"
                      name="checkOutDate"
                      value={bookingDates.checkOutDate}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>
                
                <div className="form-group">
                  <label>Number of Guests</label>
                  <select
                    name="guests"
                    value={bookingDates.guests}
                    onChange={handleInputChange}
                    required
                  >
                    {[1, 2, 3, 4, 5, 6].map(num => (
                      <option key={num} value={num}>{num} {num === 1 ? 'guest' : 'guests'}</option>
                    ))}
                  </select>
                </div>
                
                <div className="price-summary">
                  <div className="price-row">
                    <span>Nightly Rate:</span>
                    <span>${selectedHotel.price}/night</span>
                  </div>
                  <div className="price-row">
                    <span>Number of Nights:</span>
                    <span>3 nights</span>
                  </div>
                  <div className="price-row">
                    <span>Estimated Total:</span>
                    <span>${selectedHotel.price * 3}</span>
                  </div>
                </div>
                
                <button type="submit" className="book-now-btn">
                  Confirm Reservation
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="search-menu">
        <div className={`menu-item ${activeTab === 'search-all' ? 'active' : ''}`}>
          <Link to="/" className="menu-link">
            Search All
            <div className="underline" />
          </Link>
        </div>
        <div className={`menu-item ${activeTab === 'hotels' ? 'active' : ''}`}>
          <Link to="/hotels" className="menu-link">
            Hotels
            <div className="underline" />
          </Link>
        </div>
        <div className={`menu-item ${activeTab === 'cars' ? 'active' : ''}`}>
          <Link to="/cars" className="menu-link">
            Cars for Rent
            <div className="underline" />
          </Link>
        </div>
        <div className={`menu-item ${activeTab === 'restaurants' ? 'active' : ''}`}>
          <Link to="/restaurants" className="menu-link">
            Restaurants
            <div className="underline" />
          </Link>
        </div>
        <div className={`menu-item ${activeTab === 'tours' ? 'active' : ''}`}>
          <Link to="/tours" className="menu-link">
            tours
            <div className="underline" />
          </Link>
        </div>
      </div>
      
      <div className="content">
        <h1>Georgian Hospitality Experience</h1>
        <p className="subtitle">
          Discover the perfect stay for your Georgian adventure
        </p>
        
        <div className="restaurant-filters">
          {["All", "Tbilisi", "Batumi", "Mountains", "Luxury", "Resorts"].map(filter => (
            <div 
              key={filter}
              className={`filter ${activeFilter === filter ? 'active' : ''}`}
              onClick={() => setActiveFilter(filter)}
            >
              {filter}
            </div>
          ))}
        </div>
        
        <div className="restaurants-grid">
          {filteredHotels.map(hotel => (
            <div className="restaurant-card" key={hotel.id}>
              <div className={`restaurant-image ${hotel.image}`}>
                <div className="rating">
                  <span className="star">★</span> {hotel.rating}
                </div>
                <div className="location-tag">
                  {hotel.location}
                </div>
                <div className="price-tag">
                  ${hotel.price}<span>/night</span>
                </div>
              </div>
              <div className="restaurant-details">
                <h3>{hotel.name}</h3>
                <p>{hotel.description}</p>
                <div className="specialties">
                  {hotel.features.map((item, index) => (
                    <span key={index} className="specialty">{item}</span>
                  ))}
                </div>
                <button 
                  className="reserve-btn"
                  onClick={() => handleBookNow(hotel)}
                >
                  Book Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}