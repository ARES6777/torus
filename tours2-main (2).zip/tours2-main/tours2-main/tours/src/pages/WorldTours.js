// WorldTours.js
import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./WorldTours.css";

const worldTours = [
  { id: 1, title: "პარიზის რომანტიკული ტური", image: "paris.jpg", region: "საფრანგეთი", price: 1100, views: 32000 },
  { id: 2, title: "ტოკიოს კულტურული თავგადასავალი", image: "tokyo.jpg", region: "იაპონია", price: 1400, views: 29000 },
  { id: 3, title: "ნიუ იორკის მეგა ტური", image: "newyork.jpg", region: "აშშ", price: 1300, views: 35000 },
  { id: 4, title: "ბალი — სამოთხე ტროპიკებში", image: "bali.jpg", region: "ინდონეზია", price: 1200, views: 27000 },
  { id: 5, title: "დუბაის ფუფუნების ტური", image: "dubai.jpg", region: "არაბეთის გაერთიანებული საამიროები", price: 1500, views: 31000 },
  { id: 6, title: "რომისა და ვენეციის მაგია", image: "italy.jpg", region: "იტალია", price: 1250, views: 28000 },
  { id: 7, title: "ეგვიპტის მზე და ისტორია", image: "egypt.jpg", region: "ეგვიპტე", price: 1150, views: 24000 },
  { id: 8, title: "რიო და კარნავალი", image: "brazil.jpg", region: "ბრაზილია", price: 1350, views: 26000 },
  { id: 9, title: "სიდნეის საოცარი ტური", image: "australia.jpg", region: "ავსტრალია", price: 1500, views: 23000 },
  { id: 10, title: "ჩინეთის ძველი ცივილიზაცია", image: "china.jpg", region: "ჩინეთი", price: 1200, views: 25000 },
];

function WorldTours() {
  const textRef = useRef(null);
  const planeRef = useRef(null);
  const [showText, setShowText] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowText(true);
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="world-tours-bg">
      <div className="overlay">
        <div ref={planeRef} className="airplane">✈️</div>
        {showText && (
          <h1 ref={textRef} className="travel-text">
            მსოფლიოს გარშემო მოგზაურობა
          </h1>
        )}
        <div className="tour-grid">
          {worldTours.map((tour) => (
            <div key={tour.id} className="tour-card">
              <img
                src={require(`../WorldImage/${tour.image}`)}
                alt={tour.title}
                className="tour-image"
              />
              <div className="tour-title">{tour.title}</div>
              <div className="tour-footer">
                📍 {tour.region} | 👁️ {tour.views} ნახვა
              </div>
              <div className="btn-group">
                <button className="tour-btn" onClick={() => navigate(`/tour/${tour.id}`)}>დაწვრილებით</button>
                <button className="book-btn">დაჯავშნა</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default WorldTours;