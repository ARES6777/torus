import React, { useState } from "react";
import tours from "../data/Tours";
import busRoutes from "../data/busRoutes";
import "../styles/bus-reservations.css";

function BusReservations() {
  const [reservations, setReservations] = useState({});

  const handleReserve = (tourId) => {
    const name = prompt("შეიყვანეთ თქვენი სახელი:");
    const date = prompt("აირჩიეთ მგზავრობის თარიღი (YYYY-MM-DD):");

    if (!name || !date) {
      alert("გთხოვთ შეავსოთ ყველა ველი.");
      return;
    }

    setReservations((prev) => {
      const updated = { ...prev };
      updated[tourId] = {
        name,
        date,
        status: "დაჯავშნილია",
      };
      return updated;
    });

    const routeIndex = busRoutes.findIndex(route => route.tourId === tourId);
    if (routeIndex !== -1 && busRoutes[routeIndex].bookedSeats < busRoutes[routeIndex].totalSeats) {
      busRoutes[routeIndex].bookedSeats++;
    } else {
      alert("აღარ არის თავისუფალი ადგილი");
    }
  };

  return (
    <div className="bus-page">
      {/* ✅ ანიმაცია: ავტობუსი + ტექსტი */}
      <div className="bus-animation">
        <div className="bus-with-text">
          <div className="bus-icon">🚌</div>
          <div className="bus-text">ავტობუსით ტურების დაჯავშნა</div>
        </div>
      </div>

      {/* ✅ ტურების ბარათები */}
      <div className="bus-grid">
        {tours.map((tour) => {
          const route = busRoutes.find((r) => r.tourId === tour.id);
          const reservation = reservations[tour.id];

          return (
            <div className="bus-card" key={tour.id}>
              <img src={`/images/${tour.image}`} alt={tour.title} />
              <h3>{tour.title}</h3>
              <p>📍 მარშრუტი: {route.route.join(" → ")}</p>
              <p>🚌 {route.busName}</p>
              <p>🪑 ადგილი: {route.totalSeats - route.bookedSeats} დარჩენილი</p>

              {reservation ? (
                <p className="reserved">
                  ✅ დაჯავშნილია {reservation.name} | {reservation.date}
                </p>
              ) : (
                <button onClick={() => handleReserve(tour.id)}>
                  დაჯავშნა
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default BusReservations;
