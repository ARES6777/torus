import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Login.css";
import { FaGoogle } from "react-icons/fa";
import { SiFacebook } from "react-icons/si";
import { FaApple } from "react-icons/fa";


export default function Login() {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    name: ""
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isLogin) {
      console.log("Logging in with:", formData.email, formData.password);
      // Add your login logic here
    } else {
      console.log("Signing up with:", formData);
      // Add your signup logic here
    }
  };

  return (
    <section className="second-login">
      <div className="sing-in">
        <div className="top1">
          <a 
            className={isLogin ? "active" : ""} 
            onClick={() => setIsLogin(true)}
            style={{cursor: "pointer"}}
          >
            Sign in
          </a>
          <div 
            className={`reg1 ${!isLogin ? "active" : ""}`}
            onClick={() => setIsLogin(false)}
            style={{cursor: "pointer"}}
          >
            Register
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          {!isLogin && (
            <div className="inputs">
              <input
                type="text"
                name="name"
                placeholder="Full Name"
                value={formData.name}
                onChange={handleChange}
                required
              />
            </div>
          )}
          <div className="inputs">
            <input
              type="email"
              name="email"
              placeholder="Email Address"
              value={formData.email}
              onChange={handleChange}
              required
            />
            <input
              type="password"
              name="password"
              placeholder="Password"
              value={formData.password}
              onChange={handleChange}
              required
              minLength={6}
            />
          </div>

          {isLogin && (
            <div className="mark">
              <div className="stay">
                <input type="checkbox" />
                Stay signed in
              </div>
              <div className="forgot">Forgot your password?</div>
            </div>
          )}

          <div className="Singin-button">
            <button type="submit" className="button">
              {isLogin ? "Sign in" : "Register"}
            </button>
            <div className="trouble">Trouble signing in?</div>
          </div>
        </form>

        <div className="mid">OR</div>

        <div className="ways">
          <div className="with-ggl">
            <FaGoogle /> Continue with Google
          </div>
          <div className="with-fb">
            <SiFacebook /> Continue with Facebook
          </div>
          <div className="with-appl">
            <FaApple /> Continue with Apple
          </div>
        </div>

        <div className="bott-txt">
          <a>
            By clicking Sign in, Continue with Google, Facebook, or Apple, you
            agree to Us <p>Terms of Use and Privacy Policy.</p>
          </a>

        </div>
      </div>
    </section>
  );
}