import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import "./TourDetail.css";

const tours = [
  { id: 1, title: "პარიზის რომანტიკული ტური", image: "paris.jpg", region: "საფრანგეთი", price: 1100, views: 32000, description: "აღმოაჩინე პარიზის შარმი, ეიფელის კოშკი, ლუვრი და კიდევ სხვა საოცრებები.", departure: "2025-08-10 09:00", maxPeople: 25 },
  { id: 2, title: "ტოკიოს კულტურული თავგადასავალი", image: "tokyo.jpg", region: "იაპონია", price: 1400, views: 29000, description: "დაეშვი ტოკიოს ენერგიულ ქუჩებში და აღმოაჩინე იაპონური ტრადიციები.", departure: "2025-08-15 12:00", maxPeople: 20 },
  { id: 3, title: "ნიუ იორკის მეგა ტური", image: "newyork.jpg", region: "აშშ", price: 1300, views: 35000, description: "განიცადე ნიუ იორკის ენერგია და მრავალფეროვნება!", departure: "2025-08-18 10:30", maxPeople: 30 },
  { id: 4, title: "ბალი — სამოთხე ტროპიკებში", image: "bali.jpg", region: "ინდონეზია", price: 1200, views: 27000, description: "დაისვენე ბალის სანაპიროებზე და დატკბი ტროპიკული სამოთხით.", departure: "2025-08-20 08:00", maxPeople: 15 },
  { id: 5, title: "დუბაის ფუფუნების ტური", image: "dubai.jpg", region: "არაბეთის გაერთიანებული საამიროები", price: 1500, views: 31000, description: "აღმოაჩინე დუბაის ცათამბჯენები და უდაბნოს თავგადასავალი.", departure: "2025-08-22 14:00", maxPeople: 25 },
  { id: 6, title: "რომისა და ვენეციის მაგია", image: "italy.jpg", region: "იტალია", price: 1250, views: 28000, description: "დაიკარგე რომისა და ვენეციის ისტორიულ ქუჩებში.", departure: "2025-08-25 11:00", maxPeople: 18 },
  { id: 7, title: "ეგვიპტის მზე და ისტორია", image: "egypt.jpg", region: "ეგვიპტე", price: 1150, views: 24000, description: "გაიცანი პირამიდები და ფარაონების ცივილიზაცია.", departure: "2025-08-28 16:00", maxPeople: 22 },
  { id: 8, title: "რიო და კარნავალი", image: "brazil.jpg", region: "ბრაზილია", price: 1350, views: 26000, description: "შემოიგრძენი კარნავალის სილამაზე რიოში.", departure: "2025-09-01 10:00", maxPeople: 28 },
  { id: 9, title: "სიდნეის საოცარი ტური", image: "australia.jpg", region: "ავსტრალია", price: 1500, views: 23000, description: "აღმოაჩინე სიდნეის ოპერა და ბუნება.", departure: "2025-09-03 09:30", maxPeople: 20 },
  { id: 10, title: "ჩინეთის ძველი ცივილიზაცია", image: "china.jpg", region: "ჩინეთი", price: 1200, views: 25000, description: "ისწავლე ჩინეთის ისტორია და არქიტექტურა.", departure: "2025-09-06 13:00", maxPeople: 24 },
];

function TourDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const tour = tours.find((t) => t.id === parseInt(id));

  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    people: 1,
    idNumber: "",
    cardName: "",
    cardNumber: "",
    expiry: "",
    cvv: "",
  });

  const [remaining, setRemaining] = useState(tour?.maxPeople || 0); // ✅ საწყისი დარჩენილი
  const [booked, setBooked] = useState(false);
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [cancelled, setCancelled] = useState(false);

  if (!tour) return <div>ტური ვერ მოიძებნა</div>;

  const totalPrice = tour.price * formData.people;

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: name === "people" ? parseInt(value) : value,
    }));
  };

  const handleBooking = () => {
    if (
      formData.fullName &&
      formData.email &&
      formData.phone &&
      formData.idNumber &&
      formData.cardName &&
      formData.cardNumber &&
      formData.expiry &&
      formData.cvv
    ) {
      setLoading(true);
      setTimeout(() => {
        setBooked(true);
        setRemaining(prev => prev - formData.people); // ✅ აქ შემცირდება
        setLoading(false);
      }, 2000);
    } else {
      alert("გთხოვ შეავსო ყველა ველი!");
    }
  };

  const handleCancel = () => {
    setLoading(true);
    setTimeout(() => {
      setBooked(false);
      setRemaining(prev => prev + formData.people); // ✅ თანხის დაბრუნებისას დაემატოს
      setFormData({ ...formData, idNumber: "", cardName: "", cardNumber: "", expiry: "", cvv: "" });
      setCancelled(true);
      setStep(1);
      setLoading(false);
    }, 2000);
  };

  return (
    <div className="tour-detail-container">
      <h1 className="tour-detail-title">{tour.title}</h1>
      <img src={require(`../WorldImage/${tour.image}`)} alt={tour.title} className="tour-detail-image" />
      <p className="tour-detail-info">{tour.description}</p>
      <p className="tour-detail-info">📍 რეგიონი: {tour.region}</p>
      <p className="tour-detail-info">👁️ ნახვები: {tour.views}</p>
      <p className="tour-detail-info tour-price">ფასი: ${tour.price} ერთ ადამიანზე</p>
      <p className="tour-detail-info">🛫 გაფრენის დრო: {tour.departure}</p>
      <p className="tour-detail-info">🧍 დარჩენილი ადგილი: {remaining}</p>

      <iframe
        title="მდებარეობა"
        src={`https://www.google.com/maps?q=${encodeURIComponent(tour.region)}&output=embed`}
        className="tour-map"
        loading="lazy"
      ></iframe>

      {!booked && (
        <div className="booking-form">
          <h2>დაჯავშნის ფორმა</h2>

          {step === 1 && (
            <>
              <input type="text" name="fullName" placeholder="სახელი და გვარი" value={formData.fullName} onChange={handleChange} />
              <input type="email" name="email" placeholder="ელ. ფოსტა" value={formData.email} onChange={handleChange} />
              <input type="tel" name="phone" placeholder="ტელეფონი" value={formData.phone} onChange={handleChange} />
              <input type="number" name="people" placeholder="ადამიანების რაოდენობა" value={formData.people} onChange={handleChange} min="1" max={remaining} />
              <button onClick={() => setStep(2)}>შედგება შემდეგი ეტაპი</button>
            </>
          )}

          {step === 2 && (
            <>
              <input type="text" name="idNumber" placeholder="პირადი ნომერი" value={formData.idNumber} onChange={handleChange} />
              <button onClick={() => setStep(3)}>გადადი გადახდაზე</button>
            </>
          )}

          {step === 3 && (
            <>
              <input type="text" name="cardName" placeholder="ბარათის მფლობელი" value={formData.cardName} onChange={handleChange} />
              <input type="text" name="cardNumber" placeholder="ბარათის ნომერი" value={formData.cardNumber} onChange={handleChange} />
              <input type="text" name="expiry" placeholder="ვადა (MM/YY)" value={formData.expiry} onChange={handleChange} />
              <input type="text" name="cvv" placeholder="CVV კოდი" value={formData.cvv} onChange={handleChange} />
              <div className="summary">💰 ჯამური ფასი: <strong>${totalPrice}</strong></div>
              <button onClick={handleBooking} disabled={loading}>
                {loading ? "დამუშავება..." : "გადახდა და დაჯავშნა"}
              </button>
            </>
          )}
        </div>
      )}

      {booked && (
        <div className="success-msg">
          ✅ დაჯავშნა წარმატებით შესრულდა! მადლობა, {formData.fullName}!<br />
          <button onClick={handleCancel} disabled={loading}>
            {loading ? "დაბრუნება მიმდინარეობს..." : "გაუქმება და თანხის დაბრუნება"}
          </button>
        </div>
      )}

      {cancelled && !booked && (
        <div className="cancel-msg">❌ ჯავშანი გაუქმდა და თანხა დაბრუნდა!</div>
      )}

      <div className="tour-detail-buttons">
        <button className="back-btn" onClick={() => navigate("/worldtours")}>← დაბრუნება</button>
      </div>
    </div>
  );
}

export default TourDetail;