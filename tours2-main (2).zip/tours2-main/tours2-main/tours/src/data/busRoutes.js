import tours from "./Tours";

const busRoutes = tours.map((tour, index) => ({
  tourId: tour.id,
  busName: `ავტობუსი #${100 + index}`,
  route: [
    "თბილისი", 
    tour.region, 
    `${tour.title} ლოკაცია`
  ],
  totalSeats: 40,
  bookedSeats: 0
}));

export default busRoutes;
