import React, { useState } from "react";
import "../styles/gallery.css";

const galleryData = {
  "აჭარის ზღვის ტური": [
    { src: "/images/gallery/აჭარის_ზღვის_ტური-1.jpg", caption: "ბათუმის ბულვარი" },
    { src: "/images/gallery/აჭარის_ზღვის_ტური-2.jpg", caption: "ევროპის მოედანი" },
    { src: "/images/gallery/აჭარის_ზღვის_ტური-3.jpg", caption: "ალფაბეტის კოშკი" },
  ],
  "თუშეთის მთის ლაშქრობა": [
    { src: "/images/gallery/თუშეთი-1.jpg", caption: "ქომეტა" },
    { src: "/images/gallery/თუშეთი-2.jpg", caption: "ოძგი" },
    { src: "/images/gallery/თუშეთი-3.jpg", caption: "დართლო" },
  ],
  "ბორჯომის ტყის ტური": [
    { src: "/images/gallery/ბორჯომი-1.jpg", caption: "ბორჯომის პარკი" },
    { src: "/images/gallery/ბორჯომი-2.jpg", caption: "ნაკრძალი" },
    { src: "/images/gallery/ბორჯომი-3.jpg", caption: "მინერალური წყარო" },
  ],
  "კახეთის ღვინის ტური": [
    { src: "/images/gallery/კახეთი-1.jpg", caption: "სიღნაღი" },
    { src: "/images/gallery/კახეთი-2.jpg", caption: "ღვინის მარანი" },
    { src: "/images/gallery/კახეთი-3.jpg", caption: "ალაზნის ველი" },
  ],
  "სვანეთის ლაშქრობა": [
    { src: "/images/gallery/სვანეთი-1.jpg", caption: "მესტია" },
    { src: "/images/gallery/სვანეთი-2.jpg", caption: "უშგული" },
    { src: "/images/gallery/სვანეთი-3.jpg", caption: "თეთნულდი" },
  ],
  "ქუთაისის კულტურული ტური": [
    { src: "/images/gallery/ქუთაისი-1.jpg", caption: "ბაგრატი" },
    { src: "/images/gallery/ქუთაისი-2.jpg", caption: "გელათი" },
    { src: "/images/gallery/ქუთაისი-3.jpg", caption: "სათაფლია" },
  ],
  "სტეფანწმინდა & ყაზბეგი": [
    { src: "/images/gallery/ყაზბეგი-1.jpg", caption: "გერგეთის სამება" },
    { src: "/images/gallery/ყაზბეგი-2.jpg", caption: "ყაზბეგის მთა" },
    { src: "/images/gallery/ყაზბეგი-3.jpg", caption: "დარიალის ხეობა" },
  ],
  "იმერეთის ტრადიციული მოგზაურობა": [
    { src: "/images/gallery/იმერეთი-1.jpg", caption: "ოკაცეს კანიონი" },
    { src: "/images/gallery/იმერეთი-2.jpg", caption: "კინჩხა" },
    { src: "/images/gallery/იმერეთი-3.jpg", caption: "პრომეთეს მღვიმე" },
  ],
  "თბილისის ღამის ტური": [
    { src: "/images/gallery/თბილისი-1.jpg", caption: "ნარიყალა" },
    { src: "/images/gallery/თბილისი-2.jpg", caption: "მშვიდობის ხიდი" },
    { src: "/images/gallery/თბილისი-3.jpg", caption: "ძველი თბილისი" },
  ],
  "სამეგრელოს კულტურული ტური": [
    { src: "/images/gallery/სამეგრელო-1.jpg", caption: "დადიანების სასახლე" },
    { src: "/images/gallery/სამეგრელო-2.jpg", caption: "მარტვილის კანიონი" },
    { src: "/images/gallery/სამეგრელო-3.jpg", caption: "ცაგერის ტყეები" },
  ],
  "გურიის ტრადიციული დღეები": [
    { src: "/images/gallery/გურია-1.jpg", caption: "გომის მთა" },
    { src: "/images/gallery/გურია-2.jpg", caption: "გურია" },
    { src: "/images/gallery/გურია-3.jpg", caption: "ბახმარო" },
  ],
  "რაჭის მთის ტური": [
    { src: "/images/gallery/რაჭა-1.jpg", caption: "შოვი" },
    { src: "/images/gallery/რაჭა-2.jpg", caption: "ნიკორწმინდა" },
    { src: "/images/gallery/რაჭა-3.jpg", caption: "რიონი" },
  ],
  "ხევსურეთის თავგადასავალი": [
    { src: "/images/gallery/ხევსურეთი-1.jpg", caption: "შატილი" },
    { src: "/images/gallery/ხევსურეთი-2.jpg", caption: "მუცო" },
    { src: "/images/gallery/ხევსურეთი-3.jpg", caption: "არხოტი" },
  ],
  "მცხეთა-მთიანეთის ისტორიული ტური": [
    { src: "/images/gallery/მცხეთა-1.jpg", caption: "სვეტიცხოველი" },
    { src: "/images/gallery/მცხეთა-2.jpg", caption: "ჯვრის მონასტერი" },
    { src: "/images/gallery/მცხეთა-3.jpg", caption: "ბებრის ციხე" },
  ],
  "შიდა ქართლის ძველი სოფლები": [
    { src: "/images/gallery/შიდა_ქართლი-1.jpg", caption: "უფლისციხე" },
    { src: "/images/gallery/შიდა_ქართლი-2.jpg", caption: "ატენი" },
    { src: "/images/gallery/შიდა_ქართლი-3.jpg", caption: "ძამას ხეობა" },
  ],
  "სამცხე-ჯავახეთის ბუნებრივი ტური": [
    { src: "/images/gallery/ჯავახეთი-1.jpg", caption: "ვარძია" },
    { src: "/images/gallery/ჯავახეთი-2.jpg", caption: "ტაბაწყური" },
    { src: "/images/gallery/ჯავახეთი-3.jpg", caption: "ფარავნის ტბა" },
  ],
  "სრული ტური – საქართველო": [
    { src: "/images/gallery/საქართველო-1.jpg", caption: "ულამაზესი ქალაქი" },
    { src: "/images/gallery/საქართველო-2.jpg", caption: "ისიამოვნე" },
    { src: "/images/gallery/საქართველო-3.jpg", caption: "საქართველო" },
  ]
};

function GalleryPage() {
  const [selectedTour, setSelectedTour] = useState("აჭარის ზღვის ტური");
  const tourNames = Object.keys(galleryData);

  return (
    <div className="gallery-container">
      <h2>📸 ტურის გალერეა</h2>

      <div className="city-buttons">
        {tourNames.map((tour) => (
          <button
            key={tour}
            className={selectedTour === tour ? "active" : ""}
            onClick={() => setSelectedTour(tour)}
          >
            {tour}
          </button>
        ))}
      </div>

      <div className="photos">
        {galleryData[selectedTour].map((photo, index) => (
          <div key={index} className="photo-card">
            <img src={photo.src} alt={photo.caption} />
            <p>{photo.caption}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default GalleryPage;
